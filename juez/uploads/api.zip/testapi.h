#ifndef TESTAPI_H
#define TESTAPI_H

int sum(int a, int b);

#endif
